<?php
$key = "13163&key=bgpsuwBFHJKLQSVX25";//用户key！
?>