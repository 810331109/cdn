<?php

//API域名，不用动即可
$domain = "api.68yulecheng.com";

//是否开启防盗链，1为开启，0为关闭
$fdhost_on = "0";

//防盗链接数组，防盗链域名必须加上解析接口的域名例如$fdhost = ["111.com","222.com"];
//   111.com这个域名代表是解析的,222.com视频网站的
//如果播放器检测到不是这些域名打开的，立马就显示解析失败(如果防盗打开了下面没有配置解析和视频网站域名，代表允许浏览器内直接打开，不需要http|https和端口号);
$fdhost = ["",""];


//key密匙
$key = "13163&key=bgpsuwBFHJKLQSVX25";

// 是否开启移动端调用h5播放器，1为开启，0为关闭
$h5 = "1";

// 填写备用JSON接口1，没有留空
$api1 = "";

// 填写备用JSON接口2，没有留空
$api2 = "";
    
// 是否开启P2P加速，默认1为开启，0为关闭（资源大部分为m3u8建议开启）
$p2p = "0";


// 加载背景图
$load_pic = 'https://cdn.jsdelivr.net/gh/renrenmi/logo/bj.jpg';

// 右上角logo
$logo = '';

// 播放器右键文字
$right_wenzi = '视频解析系统';

// 播放器右键链接
$right_link = 'https://api.68yulecheng.com/';

// 解析页TITLE
$title = "视频解析系统-";

// 加载页面动画
$loading_pic = "https://cdn.jsdelivr.net/gh/renrenmi/logo/bj.jpg";

// loaing图片宽度
$loading_pic_width = "80";

// loaing图片高度
$loading_pic_height = "110";

// 加载页面颜色
$loading_color = "#000";

// 解析页favicon图标url
$favicon = "https://cdn.jsdelivr.net/gh/810331109/jx/favicon.ico";

// 统计代码自行加在html文件夹下的模板中

//未填写url时显示的html代码
$html = '<title>视频解析系统</title><html><meta name="robots" content="noarchive"><head></head><style>h1{color:#00A0E8; text-align:center; font-family: Microsoft Jhenghei;}p{color:#f90; font-size: 1.2rem;text-align:center;font-family: Microsoft Jhenghei;}</style><link rel="shortcut icon" href="https://cdn.jsdelivr.net/gh/810331109/jx@x/favicon.ico" type="image/x-icon"><body bgcolor="#000000"><table width="100%" height="100%" align="center"><td align="center"><h1>请输入视频链接地址</h1></table></body></html>';
	  
	  //触发防盗链时显示的html代码;
$errorRefererHtml = '<title>视频解析系统</title><html><meta name="robots" content="noarchive"><head></head><style>h1{color:#00A0E8; text-align:center; font-family: Microsoft Jhenghei;}p{color:#f90; font-size: 1.2rem;text-align:center;font-family: Microsoft Jhenghei;}</style><link rel="shortcut icon" href="https://cdn.jsdelivr.net/gh/810331109/jx@x/favicon.ico" type="image/x-icon"><body bgcolor="#000000"><table width="100%" height="100%" align="center"><td align="center"><h1>触发了防盗链！</h1></table></body></html>';	  

?>